// ignore: file_names
export 'Splashscreen.dart';
export 'onbordingScreen.dart';
export 'mainscreen.dart';
export 'HomeScreen.dart';
export 'cart/cartScreen.dart';
export 'categoriesScreen.dart';
export 'profileScreen.dart';
export 'auth/loginScreen.dart';
export 'auth/register.dart';
export 'auth/forgot.dart';
export 'Prescriptions/prescriptions.dart';
