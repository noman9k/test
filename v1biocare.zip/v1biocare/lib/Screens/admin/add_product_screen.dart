import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:v1biocare/providers/add_product_provide.dart';

class AddProductScreen extends StatefulWidget {
  static const String id = 'add-product-screen';
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AddProductProvider>().getCategories();
    });
  }

  @override
  void dispose() {
    super.dispose();
    mydispose();
  }

  void mydispose() {
    nameController.dispose();
    priceController.dispose();
    descriptionController.dispose();
    brandController.dispose();
    categoryController.dispose();
    subCategoryController.dispose();
  }

  TextEditingController nameController = TextEditingController();

  TextEditingController priceController = TextEditingController();

  TextEditingController descriptionController = TextEditingController();

  TextEditingController brandController = TextEditingController();

  TextEditingController categoryController = TextEditingController();

  TextEditingController subCategoryController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Product Screen'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // add Image from Galary or Camera
              Stack(
                children: [
                  Container(
                    // alignment: Alignment.center,
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: Colors.grey.shade400,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: Colors.black,
                          width: 1,
                        )),
                    height: 300,
                    child:
                        context.watch<AddProductProvider>().pickedFile == null
                            ? const Center(
                                child: Text('Please Select Image from Galary '))
                            : Image.file(
                                fit: BoxFit.fill,
                                width: double.infinity,
                                File(context
                                    .watch<AddProductProvider>()
                                    .pickedFile!
                                    .path),
                              ),
                  ),
                  Positioned(
                    top: 0,
                    right: 0,
                    child: ElevatedButton(
                      onPressed: () => context
                          .read<AddProductProvider>()
                          .getImage(ImageSource.gallery),
                      child: const Text('+     Image'),
                    ),
                  ),
                ],
              ),
              // add Product Name
              myTextField(nameController, 'Name'),
              const SizedBox(height: 20),

              myTextField(brandController, 'Brand'),
              const SizedBox(height: 20),

              myTextField(priceController, 'Price'),

              const SizedBox(height: 20),
              myTextField(descriptionController, 'Description', true),
              const SizedBox(height: 20),
              const Text('Select Category'),
              DropdownButton<String>(
                value: context.watch<AddProductProvider>().selectedCategory,
                items: context
                    .watch<AddProductProvider>()
                    .categories
                    .map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (value) {
                  context.read<AddProductProvider>().updateCategory(value);
                },
              ),

              const SizedBox(height: 20),
              const Text('Select SubCategory'),
              DropdownButton<String>(
                value: context.watch<AddProductProvider>().selectedSubCategory,
                items: context
                    .watch<AddProductProvider>()
                    .subCategories
                    .map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (value) {
                  context.read<AddProductProvider>().updateSubCategory(value);
                },
              ),

              // add Product Button
              Center(
                child: ElevatedButton(
                    onPressed: () =>
                        context.read<AddProductProvider>().addProductToDB(
                              context: context,
                              productName: nameController.text,
                              productPrice: priceController.text,
                              productDescription: descriptionController.text,
                              productBrand: brandController.text,
                            ),
                    child: const Text('Add Product')),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget myTextField(TextEditingController controller, String hint,
      [bool isDesc = false]) {
    return TextField(
        controller: controller,
        maxLines: isDesc ? 3 : 1,
        decoration: InputDecoration(
          label: Text(hint),
          floatingLabelBehavior: FloatingLabelBehavior.always,
          hintText: hint,
          border: const OutlineInputBorder(),
        ));
  }
}
