import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:v1biocare/Screens/Screens.dart';
import 'package:v1biocare/Screens/admin/add_product_screen.dart';
import 'package:v1biocare/Screens/auth/loginScreen.dart';
import 'package:v1biocare/Screens/chat_screen.dart';
import 'package:v1biocare/models/orders_model.dart';

class AdminScreen extends StatelessWidget {
  const AdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        drawer: Drawer(
          child: ListView(
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.4),
                ),
                padding: const EdgeInsets.all(10),
                child: const Text(
                  'Admin',
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ListTile(
                title: const Text('Add Products'),
                trailing: const Icon(Icons.add_business_outlined),
                onTap: () {
                  Navigator.pop(context);

                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => AddProductScreen()));
                },
              ),
              ListTile(
                title: const Text('Logout'),
                trailing: const Icon(Icons.logout),
                onTap: () {
                  FirebaseAuth.instance.signOut();
                  // pop all and push login page
                  Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => SplashScreen()),
                      (route) => false);
                },
              ),
            ],
          ),
        ),
        appBar: AppBar(
          centerTitle: true,
          title: const Text('Admin Screen'),
          // actions: [
          //   IconButton(
          //     icon: const Icon(Icons.logout),
          //     onPressed: () {
          //       FirebaseAuth.instance.signOut();
          //       Navigator.pushReplacementNamed(context, '/login');
          //     },
          //   ),
          // ],
        ),
        body: FirestoreListView<OrdersModel>(
          query: allOrdersCollection(),
          itemBuilder: (context, snapshot) {
            OrdersModel ordersModel = snapshot.data();
            return ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatScreen(uId: ordersModel.uid!),
                  ),
                );
              },
              title: Text(ordersModel.productname!),
              subtitle: Text(ordersModel.orderstatus!),
              trailing: Text(
                DateFormat('dd/MM/yyyy\n(hh:mm)')
                    .format(ordersModel.orderdate!.toDate()),
                textAlign: TextAlign.end,
              ),
            );
          },
        ));
  }
}
