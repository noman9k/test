// ignore_for_file: prefer_const_literals_to_create_immutables, prefer_const_constructors

import 'dart:developer';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:v1biocare/Screens/Prescriptions/prescription_upload.dart';
import 'package:v1biocare/Screens/admin/admin_screen.dart';
import 'package:v1biocare/providers/orders_provider.dart';

import '../Widgets/category_widget.dart';
import '../Widgets/productWidget.dart';
import '../Widgets/widgets.dart';
import 'mainscreen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  static const String id = 'home-screen';

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // @override
  // void initState() {
  //   super.initState();
  //   // WidgetsBinding.instance.addPostFrameCallback((_) {
  //   //   Navigator.pushReplacement(
  //   //       context, MaterialPageRoute(builder: (context) => AdminScreen()));
  //   // });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(
        title: 'BioCare',
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          BannerWidget(),
          Text(
            'Products',
            style: TextStyle(
                letterSpacing: 1, fontWeight: FontWeight.bold, fontSize: 20),
          ),
          const ProductmodelWidget(),
        ],
      ),
    );
  }
}
