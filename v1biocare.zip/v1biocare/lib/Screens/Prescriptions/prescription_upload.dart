import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';

import 'dart:io';
import 'package:provider/provider.dart';

import '../../providers/prescriptions_upload_provider.dart';
import 'uploadPrescription.dart';

class Prescription extends StatefulWidget {
  const Prescription({super.key});
  static const String id = 'upload-prescription';

  @override
  State<Prescription> createState() => PrescriptionState();
}

class PrescriptionState extends State<Prescription> {
  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 10));
    WidgetsBinding.instance.addPostFrameCallback((_) {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Upload Prescription"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Prescription Upload',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  MaterialButton(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(
                        5,
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => const UploadPrescription(),
                        ),
                      );
                    },
                    child: const Text(
                      "<  Back",
                      style: TextStyle(
                          color: Color.fromARGB(255, 40, 201, 250),
                          fontSize: 18),
                    ),
                  ),
                ],
              ),
            ),
            const Divider(
              color: Colors.grey,
              height: 1,
            ),
            Column(
              children: [
                listItem(
                  'Uganda ID Front',
                  'assets/images/id.jpg',
                  'frontId',
                  onPressed: () => showDialog(
                    context: context,
                    builder: (context) => showMyDialogueBox('Uganda ID Front',
                        'assets/images/id.jpg', 'frontId', context),
                  ),
                ),
                listItem(
                  'Uganda ID Back',
                  'assets/images/id.jpg',
                  'backId',
                  onPressed: () => showDialog(
                    context: context,
                    builder: (context) => showMyDialogueBox('Uganda ID Back',
                        'assets/images/id.jpg', 'backId', context),
                  ),
                ),
                listItem(
                  'Prescription',
                  'assets/images/note.jpg',
                  'prescription',
                  onPressed: () => showDialog(
                    context: context,
                    builder: (context) => showMyDialogueBox('Prescription',
                        'assets/images/note.jpg', 'prescription', context),
                  ),
                ),
                const Divider(
                  color: Colors.grey,
                  height: 1,
                ),
                listItem('Insurance Card Front',
                    'assets/images/insurance card.png', 'insuranceCardFront',
                    optional: true,
                    onPressed: () => showDialog(
                          context: context,
                          builder: (context) => showMyDialogueBox(
                              'Insurance Card Front',
                              'assets/images/insurance card.png',
                              'insuranceCardFront',
                              context),
                        )),
                listItem('Insurance Card Back',
                    'assets/images/insurance card.png', 'insuranceCardBack',
                    optional: true,
                    onPressed: () => showDialog(
                          context: context,
                          builder: (context) => showMyDialogueBox(
                              'Insurance Card Back',
                              'assets/images/insurance card.png',
                              'insuranceCardBack',
                              context),
                        )),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(2),
                        borderSide: const BorderSide(color: Colors.grey),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(2),
                        borderSide: BorderSide(color: Colors.green),
                      ),
                      hintText: 'Write the Notes',
                      hintStyle: const TextStyle(
                          color: Colors.grey, fontStyle: FontStyle.italic),
                    ),
                    maxLines: 3,
                  ),
                ),
                ElevatedButton(
                    onPressed: () {},
                    child: const Text(
                      'Submit',
                      style: TextStyle(color: Colors.white),
                    ))
              ],
            )
          ],
        ),
      ),
    );
  }

  buildImageWidget({required IconData iconData, required Function onPressed}) {
    return InkWell(
      onTap: () => onPressed(),
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Icon(
            iconData,
            size: 30,
          ),
        ),
      ),
    );
  }
}

Widget showMyDialogueBox(
    String title, String imagePath, String imageType, BuildContext context) {
  return AlertDialog(
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(textAlign: TextAlign.center, title),
        IconButton(
          onPressed: context.read<PrescriptionsUploadProvider>().dismissDialog
              ? () {
                  Navigator.pop(context);
                }
              : null,
          icon: const Icon(
            Icons.close,
            color: Colors.black,
          ),
        ),
      ],
    ),
    content: SizedBox(
      height: 150,
      width: 300,
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.4),
              BlendMode.dstATop,
            ),
            image: ExactAssetImage(
              imagePath,
            ),
            fit: BoxFit.cover,
          ),
        ),
        child: context.watch<PrescriptionsUploadProvider>().pickedFile == null
            ? null
            : Image.file(
                File(context
                    .watch<PrescriptionsUploadProvider>()
                    .pickedFile!
                    .path),
                fit: BoxFit.cover,
              ),
      ),
    ),
    actions: [
      Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.grey.withOpacity(0.3),
                    elevation: 0),
                onPressed: () => context
                    .read<PrescriptionsUploadProvider>()
                    .getImage(ImageSource.camera, imageType),
                icon: const Icon(Icons.camera_alt),
                label: const Text('Camera'),
              ),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.grey.withOpacity(0.3),
                    elevation: 0),
                onPressed: () => context
                    .read<PrescriptionsUploadProvider>()
                    .getImage(ImageSource.gallery, imageType),
                icon: const Icon(Icons.image),
                label: const Text('Galary'),
              ),
            ],
          ),
          ElevatedButton(
            onPressed:
                context.watch<PrescriptionsUploadProvider>().pickedFile ==
                            null ||
                        context.watch<PrescriptionsUploadProvider>().isUploading
                    ? null
                    : () async {
                        await context
                            .read<PrescriptionsUploadProvider>()
                            .uploadImage(imageType);

                        // ignore: use_build_context_synchronously
                        Navigator.pop(context);
                      },
            child: Text(context.watch<PrescriptionsUploadProvider>().isUploading
                ? 'Uploading....'
                : '    Upload    '),
          )
        ],
      ),
    ],
  );
}

Widget listItem(String title, String imgpath, String imageType,
    {required Function onPressed, Function? rebuild, bool optional = false}) {
  try {
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('prescriptions')
            .doc(FirebaseAuth.instance.currentUser!.uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.active) {
            return ListTile(
              title: Text(title),
              leading: Image.asset(
                imgpath,
                height: 50,
                width: 50,
              ),
              subtitle: optional
                  ? const Text(
                      'optional',
                      style: TextStyle(color: Colors.grey),
                    )
                  : null,
              trailing: snapshot.data![imageType].toString().contains('not')
                  ? IconButton(
                      onPressed: () => onPressed(),
                      icon: const Icon(Icons.add_a_photo_outlined))
                  : SizedBox(
                      width: 100,
                      height: 100,
                      child: Image.network(
                        snapshot.data![imageType],
                        fit: BoxFit.contain,
                        width: 100,
                        height: 100,
                      ),
                    ),
            );
          }
          return const CircularProgressIndicator();
        });
  } catch (e) {
    log(e.toString());
  }
  return ListTile(
    title: Text(title),
    leading: Image.asset(
      imgpath,
      height: 50,
      width: 50,
    ),
    subtitle: optional
        ? const Text(
            'optional',
            style: TextStyle(color: Colors.grey),
          )
        : null,
    trailing: StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('prescriptions')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .snapshots(),
      builder: (context, snapshot) {
        log(snapshot.data![imageType].toString());
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(
              color: Colors.green,
            ),
          );
        }

        if (snapshot.data![imageType].toString() == 'notUploaded') {
          return IconButton(
              icon: const Icon(Icons.add_a_photo),
              onPressed: () {
                onPressed();
              });
        }

        return Container(
          padding: const EdgeInsets.only(bottom: 10),
          margin: const EdgeInsets.only(bottom: 10),
          child: CachedNetworkImage(
            imageUrl: snapshot.data![imageType].toString(),
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: imageProvider,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
        );
        // Image.network(
        //   snapshot.data![imageType].toString(),
        //   height: 100,
        //   width: 100,
        //   fit: BoxFit.cover,
        // );
      },
    ),
  );
}
