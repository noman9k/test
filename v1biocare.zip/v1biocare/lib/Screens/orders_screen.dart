import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:intl/intl.dart';
import 'package:v1biocare/Screens/cart/payment_summary/order_item.dart';
import 'package:v1biocare/models/orders_model.dart';

class OrderScreen extends StatelessWidget {
  const OrderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Orders List"),
        ),
        body: FirestoreListView<OrdersModel>(
          query: ordersWithUserIdCollection(
              userId: FirebaseAuth.instance.currentUser!.uid),
          itemBuilder: (context, snapshot) {
            OrdersModel ordersModel = snapshot.data();
            return ListTile(
              title: Text(ordersModel.productname!),
              subtitle: Text(ordersModel.orderstatus!),
              trailing: Text(
                DateFormat('dd/MM/yyyy\n(hh:mm)')
                    .format(ordersModel.orderdate!.toDate()),
                textAlign: TextAlign.end,
              ),
            );
          },
        ));
  }
}
