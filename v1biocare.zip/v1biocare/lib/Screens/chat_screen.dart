import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:provider/provider.dart';
import 'package:v1biocare/models/message.dart';
import 'package:intl/intl.dart';

import '../chat/chat_provider.dart';
import 'admin/user_details_screen.dart';

class ChatScreen extends StatefulWidget {
  ChatScreen({super.key, required this.uId});
  final String uId;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController messageController = TextEditingController();

  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: AppBar(
            title: const Text('Chat'),
            actions: [
              IconButton(
                icon: const Icon(Icons.account_circle_outlined),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            UserDetailsScreen(uid: widget.uId)),
                  );
                },
              ),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: FirestoreListView<Message>(
                  controller: scrollController,
                  addAutomaticKeepAlives: true,
                  reverse: true,
                  query: getChatStream(widget.uId),
                  itemBuilder: (context, snapshot) {
                    final message = snapshot.data();
                    return Container(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: message.senderId !=
                                FirebaseAuth.instance.currentUser!.uid
                            ? MainAxisAlignment.start
                            : MainAxisAlignment.end,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: message.senderId !=
                                      FirebaseAuth.instance.currentUser!.uid
                                  ? Colors.grey.withOpacity(0.4)
                                  : Colors.green.withOpacity(0.4),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(message.text!),
                                const SizedBox(height: 3),
                                Text(
                                  textAlign: TextAlign.end,
                                  DateFormat('hh:mm')
                                      .format(message.createdAt!.toDate()),
                                  style: const TextStyle(
                                    fontSize: 11,
                                    color: Color.fromARGB(255, 130, 128, 128),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 10, left: 10, right: 10),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: messageController,
                        decoration: const InputDecoration(
                          focusedBorder: OutlineInputBorder(
                            // borderSide: BorderSide(color: Colors.grey),
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          hintText: 'Type a message',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () async {
                        if (messageController.text.isEmpty) return;
                        await context.read<ChatProvider>().sendMessage(
                            text: messageController.text, uId: widget.uId);
                        scrollController.animateTo(-10,
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeOut);

                        messageController.clear();
                      },
                      icon: const Icon(Icons.send),
                    ),
                  ],
                ),
              ),
            ],
          )),
    );
  }
}
