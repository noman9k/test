import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;
import 'package:v1biocare/providers/orders_provider.dart';

class StripeProvider with ChangeNotifier {
  Map<String, dynamic>? paymentIntent;

  Future<bool> makePayment({
    required BuildContext context,
    required String amount,
    required String productId,
    required String productName,
    required String productPrice,
    required String productQuantity,
  }) async {
    EasyLoading.dismiss();

    try {
      //STEP 1: Create Payment Intent
      paymentIntent = await createPaymentIntent(amount, 'UGX');

      //STEP 2: Initialize Payment Sheet
      await Stripe.instance
          .initPaymentSheet(
              paymentSheetParameters: SetupPaymentSheetParameters(
                  paymentIntentClientSecret: paymentIntent![
                      'client_secret'], //Gotten from payment intent
                  style: ThemeMode.light,
                  merchantDisplayName: 'Ikay'))
          .then((value) {});

      //STEP 3: Display Payment sheet
      bool result = await displayPaymentSheet(context);
      if (result) {
        EasyLoading.show(status: 'Placing order...');
        await OrdersProvider().addProductToOrders(
            productId: productId,
            productName: productName,
            productPrice: double.parse(productPrice),
            productQuantity: double.parse(productQuantity));
        EasyLoading.dismiss();
        return result;
      }

      log('result: $result');

      return result;
      // return await displayPaymentSheet(context);
    } catch (err) {
      throw Exception(err);
    }
  }

  createPaymentIntent(String amount, String currency) async {
    try {
      //Request body
      Map<String, dynamic> body = {
        'amount': calculateAmount(amount),
        'currency': currency,
      };

      //Make post request to Stripe
      var response = await http.post(
        Uri.parse('https://api.stripe.com/v1/payment_intents'),
        headers: {
          'Authorization':
              'Bearer sk_test_51MFyzwGRlHWLaKEW92o1iDzdw7MOqusVvvGjmyjlKn6PGKb7LxxonHqI7MVaASs7uCE92YHhlLKK3gZIeq7Q8x6x00DTKEEqu9',
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: body,
      );
      return json.decode(response.body);
    } catch (err) {
      throw Exception(err.toString());
    }
  }

  Future<bool> displayPaymentSheet(BuildContext context) async {
    bool success = false;
    try {
      await Stripe.instance.presentPaymentSheet().then((value) {
        paymentIntent = null;
        success = true;
      }).onError((error, stackTrace) {
        log('onerror: $error');
        throw Exception(error);
      });
    } on StripeException catch (e) {
      print('Error is:---> $e');
    } catch (e) {
      print('$e');
    }
    return success;
  }
}

calculateAmount(String amount) {
  final a = (int.parse(amount)) * 100;
  return a.toString();
}
