import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:v1biocare/models/orders_model.dart';

class OrdersProvider extends ChangeNotifier {
  bool _paymentSuceess = false;

  bool get paymentSuceess => _paymentSuceess;

  void setPaymentSuceess(bool value) {
    _paymentSuceess = value;
    notifyListeners();
  }

  //
  //
  //
  Future<bool> addProductToOrders(
      {required String productId,
      required String productName,
      required double productPrice,
      required double productQuantity}) async {
    try {
      log('message   messagemessagemessagemessagemessagemessagemessage messagemessage');
      Position location = await getcuttentlocation();
      await FirebaseFirestore.instance
          .collection('orders')
          .doc()
          // .collection('userOrders')
          // .doc(productId)
          .set(OrdersModel(
                  productId: productId,
                  orderid: 'orderid',
                  productname: productName,
                  productprice: productPrice,
                  quantity: 1,
                  uid: FirebaseAuth.instance.currentUser?.uid ?? '',
                  total: 1,
                  orderstatus: 'active',
                  orderdate: Timestamp.fromDate(DateTime.now()),
                  orderaddress: GeoPoint(location.latitude, location.longitude),
                  orderpayment: 'cash')
              .toJson());

      notifyListeners();

      return true;
    } catch (e) {
      return false;
    }
  }

  Future<Position> getcuttentlocation() async {
    LocationPermission permission;
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.deniedForever) {
        return Future.error('Location Not Available');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error('Location Not Available');
    }
    if (permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always) {
      return await Geolocator.getCurrentPosition();
    } else {
      throw Exception('Error');
    }
  }
}
