import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';

class AddProductProvider extends ChangeNotifier {
  final ImagePicker _picker = ImagePicker();
  final storageRef = FirebaseStorage.instance.ref();
  CollectionReference productCollection =
      FirebaseFirestore.instance.collection('products');
  double progress = 0.0;
  XFile? pickedFile;

  bool _isUploading = false;

  String? selectedCategory;

  String? selectedSubCategory;

  bool get isUploading => _isUploading;

  List<String> categories = [];
  List<String> subCategories = [];

  void setIsUploading(bool isUploading) {
    _isUploading = isUploading;
    notifyListeners();
  }

  void getImage(
    ImageSource imageSource,
  ) async {
    pickedFile = await _picker.pickImage(source: imageSource);
    notifyListeners();
  }

  Future<String> uploadImage() async {
    setIsUploading(true);
    if (pickedFile != null) {
      var snapshot = await storageRef
          .child('images/products')
          .putFile(File(pickedFile!.path));

      var imgUrl = await snapshot.ref.getDownloadURL();

      return imgUrl;
    }
    return 'Error Uploading Image';
  }

  Future<void> addProductToDB({
    required BuildContext context,
    required String productName,
    required String productPrice,
    required String productDescription,
    required String productBrand,
  }) async {
    setIsUploading(true);
    EasyLoading.show(status: 'Adding Product... ');

    var imgUrl = await uploadImage();
    log(imgUrl);
    await productCollection.add({
      'productName': productName,
      'productPrice': productPrice,
      'productDescription': productDescription,
      'productBrand': productBrand,
      'userId': FirebaseAuth.instance.currentUser!.uid,
      'image': imgUrl,
      'category': selectedCategory,
      'subcategory': selectedSubCategory,
    }).then((value) {
      setIsUploading(false);
      EasyLoading.dismiss();
      print('Product Added');
      Navigator.pop(context);
    }).catchError((error) {
      setIsUploading(false);
      print('Failed to add product: $error');
    });
  }

  void getCategories() async {
    pickedFile = null;
    categories = [];
    subCategories = [];

    // get categories from firebase
    await FirebaseFirestore.instance
        .collection('categories')
        .where('active', isEqualTo: true)
        .get()
        .then((QuerySnapshot querySnapshot) {
      for (var doc in querySnapshot.docs) {
        categories.add(doc['catName']);
      }
    });
    await FirebaseFirestore.instance
        .collection('subcategory')
        // .where('active', isEqualTo: true)
        .get()
        .then((QuerySnapshot querySnapshot) {
      for (var doc in querySnapshot.docs) {
        subCategories.add(doc['subcategoryname']);
      }
    });
  }

  void updateCategory(String? value) {
    selectedCategory = value;
    notifyListeners();
  }

  void updateSubCategory(String? value) {
    selectedSubCategory = value;
    notifyListeners();
  }
}
