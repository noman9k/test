import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutterwave_standard/flutterwave.dart';
import 'package:v1biocare/providers/orders_provider.dart';

class MyFlutterwave {
  Future<bool> handlePaymentInitialization({
    required BuildContext context,
    required String amount,
    required String productId,
    required String productName,
    required String productPrice,
    required String productQuantity,
  }) async {
    final Customer customer = Customer(
        name: "Flutterwave Developer",
        phoneNumber: "1234566677777",
        email: "customer@customer.com");
    final Flutterwave flutterwave = Flutterwave(
      context: context,
      publicKey: "FLWPUBK_TEST-bb38d856448ded0108e5e0bf61428db7-X",
      currency: "UGX",
      redirectUrl: "https://www.google.com/",
      txRef: DateTime.now().millisecondsSinceEpoch.toString(),
      amount: amount,
      customer: customer,
      paymentOptions: "ussd, card, barter, payattitude",
      customization: Customization(title: "My Payment"),
      isTestMode: true,
    );
    final ChargeResponse response = await flutterwave.charge();
    log(response.success.toString());
    if (response.success == true) {
      EasyLoading.show(status: 'Placing order...');
      await OrdersProvider().addProductToOrders(
          productId: productId,
          productName: productName,
          productPrice: double.parse(productPrice),
          productQuantity: double.parse(productQuantity));
      EasyLoading.dismiss();
      return true;
    } else {
      return false;
    }
  }
}
