import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class PrescriptionsUploadProvider extends ChangeNotifier {
  final ImagePicker _picker = ImagePicker();
  final storageRef = FirebaseStorage.instance.ref();
  CollectionReference prescriptionCollection =
      FirebaseFirestore.instance.collection('prescriptions');
  double progress = 0.0;
  XFile? pickedFile;

  // Future<void> pickImage(ImageSource imageSource) async {}

  bool _isUploading = false;
  bool _dismissDialog = false;
  bool get dismissDialog => _dismissDialog;

  void setDismissDialog(bool dismissDialog) {
    _dismissDialog = dismissDialog;
    notifyListeners();
  }

  bool get isUploading => _isUploading;

  void setIsUploading(bool isUploading) {
    _isUploading = isUploading;
    notifyListeners();
  }

  void getImage(ImageSource imageSource, String imageType) async {
    pickedFile = await _picker.pickImage(source: imageSource);
    notifyListeners();
  }

  Future<void> initializePrescription() async {
    await FirebaseFirestore.instance
        .collection('prescriptions')
        .doc(FirebaseAuth.instance.currentUser?.uid ?? '00')
        .set({
      'userId': FirebaseAuth.instance.currentUser!.uid,
      'frontId': 'notUploaded',
      'backId': 'notUploaded',
      'insuranceCardBack': 'notUploaded',
      'insuranceCardFront': 'notUploaded',
      'prescription': 'notUploaded',
    });
  }

  Future<void> uploadImage(String imageType) async {
    setIsUploading(true);
    setDismissDialog(false);
    if (pickedFile != null) {
      var snapshot = await storageRef
          .child('images/$imageType')
          .putFile(File(pickedFile!.path));

      var imgUrl = await snapshot.ref.getDownloadURL();
      await FirebaseFirestore.instance
          .collection('prescriptions')
          .doc(FirebaseAuth.instance.currentUser?.uid ?? '00')
          .set({
        'userId': FirebaseAuth.instance.currentUser!.uid,
        imageType: imgUrl,
      }, SetOptions(merge: true));

      setIsUploading(false);

      setDismissDialog(true);
      pickedFile = null;

      // save the image url to the database

    }
  }
}
