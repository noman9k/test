import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:v1biocare/models/message.dart';

class ChatProvider extends ChangeNotifier {
  CollectionReference chatRef = FirebaseFirestore.instance.collection('chat');
  List<Message> messages = [];
  Future<bool> sendMessage({String? text, required String uId}) async {
    try {
      await chatRef.doc(uId).collection('message').doc().set({
        'text': text,
        'senderId': FirebaseAuth.instance.currentUser?.uid,
        'createdAt': DateTime.now(),
      });
      notifyListeners();
      return true;
    } catch (e) {
      print(e);
      return false;
    }
  }

  getChatStream(String uId) {
    final messageStream = chatRef
        .doc(uId)
        .collection('message')
        .orderBy('createdAt', descending: true)
        .snapshots();
    messageStream.listen((event) {
      messages = event.docs.map((e) => Message.fromJson(e.data())).toList();
      notifyListeners();
    });
    return messageStream;
  }
}
