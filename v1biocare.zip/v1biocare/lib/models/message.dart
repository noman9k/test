import 'package:cloud_firestore/cloud_firestore.dart';

import '../firebaseServices/firebaseservice.dart';

class Message {
  String? senderId;
  Timestamp? createdAt;
  String? text;

  Message({this.senderId, this.createdAt, this.text});

  Message.fromJson(Map<String, dynamic> json) {
    senderId = json['senderId'] as String;
    createdAt = json['createdAt'] as Timestamp;
    text = json['text'] as String;
  }

  Map<String, Object?> toJson() {
    final Map<String, Object?> data = Map<String, Object?>();
    data['senderId'] = senderId;
    data['createdAt'] = createdAt;
    data['text'] = text;
    return data;
  }
}

FirebaseService _service = FirebaseService();
getChatStream(String? uId) {
  final messageStream = _service.chat
      .doc(uId)
      .collection('message')
      .orderBy('createdAt', descending: true)
      .withConverter<Message>(
        fromFirestore: (snapshot, _) => Message.fromJson(snapshot.data()!),
        toFirestore: (movie, _) => movie.toJson(),
      );

  return messageStream;
}
