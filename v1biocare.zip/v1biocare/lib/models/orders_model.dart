import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../firebaseServices/firebaseservice.dart';

class OrdersModel extends ChangeNotifier {
  final String? productId;
  final String? orderid;
  final String? productname;
  final double? productprice;
  final double? quantity;
  final double? total;
  final String? orderstatus;
  final Timestamp? orderdate;
  final GeoPoint? orderaddress;
  final String? orderpayment;
  final String? uid;

  OrdersModel({
    this.productId,
    this.orderid,
    this.productname,
    this.productprice,
    this.quantity,
    this.uid,
    this.total,
    this.orderstatus,
    this.orderdate,
    this.orderaddress,
    this.orderpayment,
  });

  OrdersModel.fromJson(Map<String, dynamic?> json)
      : this(
          productId: json['productId']! as String,
          uid: json['uid']! as String,
          orderid: json['orderid']! as String,
          productname: json['productname']! as String,
          productprice: json['productprice'] ?? 0.0,
          total: json['total'] ?? 0.0,
          quantity: json['quantity'] ?? 0.0,
          orderstatus: json['orderstatus']! as String,
          orderdate: json['orderdate'] as Timestamp,
          orderaddress: json['orderaddress']! as GeoPoint,
          orderpayment: json['orderpayment']! as String,
        );

  Map<String, Object?> toJson() {
    return {
      'productId': productId,
      'uid': uid,
      'quantity': quantity,
      'orderid': orderid,
      'productname': productname,
      'productprice': productprice,
      'total': total,
      'orderstatus': orderstatus,
      'orderdate': orderdate,
      'orderaddress': orderaddress,
      'orderpayment': orderpayment,
    };
  }
}

final FirebaseService _service = FirebaseService();

allOrdersCollection() {
  return _service.orders
      .where('orderstatus', isEqualTo: 'active')
      .orderBy('orderdate', descending: true)
      .withConverter<OrdersModel>(
        fromFirestore: (snapshot, _) => OrdersModel.fromJson(snapshot.data()!),
        toFirestore: (movie, _) => movie.toJson(),
      );
}

ordersWithUserIdCollection({required String userId}) {
  return _service.orders
      .where('uid', isEqualTo: userId)
      .where('orderstatus', isEqualTo: 'active')
      .withConverter<OrdersModel>(
        fromFirestore: (snapshot, _) => OrdersModel.fromJson(snapshot.data()!),
        toFirestore: (movie, _) => movie.toJson(),
      );
}
