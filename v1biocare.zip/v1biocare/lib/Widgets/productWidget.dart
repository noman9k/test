import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutterfire_ui/firestore.dart';

import '../Screens/product_details.dart';
import '../models/productModel.dart';

class ProductmodelWidget extends StatelessWidget {
  final String? selectedsubcat;
  const ProductmodelWidget({super.key, this.selectedsubcat});

  @override
  Widget build(BuildContext context) {
    return FirestoreQueryBuilder<ProductModel>(
      query: productCollection(selectedSubcat: selectedsubcat),
      builder: (context, snapshot, _) {
        if (snapshot.isFetching) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Text('error ${snapshot.error}');
        }

        return Expanded(
          child: GridView.builder(
            shrinkWrap: true,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: snapshot.docs.isEmpty ? 1 / .1 : 1 / 1.1,
            ),
            padding: const EdgeInsets.all(10),
            itemCount: snapshot.docs.length,
            itemBuilder: (context, index) {
              if (snapshot.hasMore && index + 1 == snapshot.docs.length) {
                snapshot.fetchMore();
              }
              var productIndex = snapshot.docs[index];
              ProductModel product = snapshot.docs[index].data();
              String productID = productIndex.id;
              return InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext context) => ProductDetailsScreen(
                        // productId: productID,
                        product: product,
                      ),
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 10),
                      Center(
                        child: CachedNetworkImage(
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                            imageUrl: product.image ??
                                'https://firebasestorage.googleapis.com/v0/b/v1biocare.appspot.com/o/Products%2Fproduct%20(1).jpg?alt=media&token=8b8b8b8b-8b8b-8b8b-8b8b-8b8b8b8b8b8b'),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          product.productname ?? 'Product Name',
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Text(
                          'UGX ${product.productprice}',
                          style: const TextStyle(
                              fontSize: 14, fontWeight: FontWeight.w400),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
